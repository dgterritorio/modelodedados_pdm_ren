<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1">
<context>
    <name>CatalogDialog</name>
    <message>
        <location filename="../pdm_importar_md_dialog.py" line="97"/>
        <source>Erro: Nenhuma das colunas esperadas foi encontrada no catálogo.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PdmImportarMd</name>
    <message>
        <location filename="../pdm_importar_md.py" line="177"/>
        <source>&amp;PDM Importar MD</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pdm_importar_md.py" line="164"/>
        <source>PDM - Importar para o Modelo de Dados - gpkg</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
